import UIKit

//MARK: - Exercise 1

var numberOne: Float = 3.14
var numberTwo: Float = 42.0
var numberThree: Double = Double(numberOne + numberTwo)
print(numberThree)


//MARK: - Exercise 2

var numbOne: Int = 4
var numbTwo: Int = 3
let numbThree = numbOne / numbTwo
let numbFour = numbOne % numbTwo
print("When dividing \(numbOne) by \(numbTwo), the result is \(numbThree), the remainder is \(numbFour)")


//MARK: - Exercise 3

var qty = 10
qty = 1

var price = 1000

var totalSum = price * qty

if qty < 5 {
    price = 1000
    totalSum = price * qty
}else if qty >= 5 && qty < 10 {
    price = 900
    totalSum = price * qty
}else if qty >= 10 {
    price = 850
    totalSum = price * qty
}
print("new: \(qty) MacBook Pro with the price of: \(price) EUR, will cost you: \(totalSum) Eur")


//MARK: - Exercise 4

let userInputAge = Int("33a")


//MARK: - Exercise 5

let myAge = 35
let monthsInYear = 12
let daysInYear = 365

var totalYearsFromBirth: Int = myAge
var totalMonthsFromBirth: Int = (myAge * monthsInYear) + 4
var totalDaysFromBirth: Int = myAge * daysInYear

print("Total years: \(totalYearsFromBirth) , total months: \(totalMonthsFromBirth), total days: \(totalDaysFromBirth) have passed")


//MARK: - Exeercise 6

let monthInYear = 3
var quarter = " "

switch monthInYear {
case 1...3:
    quarter = "first quarter"
case 4...6:
    quarter = "second quarter"
case 7...9:
    quarter = "third quarter"
case 10...12:
    quarter = "fourth quarter"
default:
    quarter = "No clue"
}

print("I was born in the \(quarter)")
