import UIKit

//MARK: - Exercise 1

var period = 5
var amount: Double = 500_000
var rate = 0.05

var deposit = Double()

var profit = Double(){
    didSet{
        deposit = profit + amount
    }
}

for _ in 1...period{
    profit += amount * Double(rate)
}

print("Amount of income after \(period) years will be \(profit) Eur. My total deposit will be \(deposit) Eur !")



//MARK: - Exercise 2


let numbers = [1, 4, 6, 17, 27, 38];
var evenNumber = numbers.filter { $0 % 2 == 0 }

for evenNumbers in numbers{
    if evenNumbers % 2 == 0 {
        print("My even numbers are: \(evenNumber)")
    }
}



//MARK: - Exercise 3

//var counter = 0

for counter in 1... {
    let randomNumber =
    Int.random(in: 1...100)
    if randomNumber == 5 {
        print("Number 5 will be after \(counter) shuffles")
        break
    }
}

//MARK: - Exercise 4

let distance = 10
var way = 0

let dayWay = 2
let nightWay = -1

var numberOfDays = 0

while way < distance{
    way += dayWay
    numberOfDays += 1
    way += nightWay
}
print("Bug will spend \(numberOfDays) days to reach top of the post")
