import UIKit


//MARK: - Exercise 1

let firstString = "I'm learning"
let secondString = "swift"
print("\(firstString) \(secondString)!!!")


//MARK: - Exercise 2

let myAge = 35
var myAgeInTenYears: Int = myAge + 10
let daysInYear = 365.25
var daysPassed: Float = Float(Double(myAgeInTenYears) * daysInYear)
print("My age is \(myAge). After 10 years, I will be \(myAgeInTenYears) years old. From the moment of my birthday have passed approximately \(daysPassed) days")

//MARK: - Exercise 3

var AC: Float = 8.0
var CB: Float = 6.0

var areaTriangle = Int(AC) * Int(CB) / 2

var periTriangle = sqrt((AC * AC) + (CB * CB)) + (AC) + (CB)

var hypoTriangle = sqrt((AC * AC) + (CB * CB))


struct RightTriangle {

var AC: Double
var CB: Double

var hypotenuse : Double {
    get {
        return sqrt((self.AC * self.AC) + (self.CB * self.CB))
    }
  }
}
var rightTriangleOne = RightTriangle(AC: 8.0, CB: 6.0)
rightTriangleOne.hypotenuse
